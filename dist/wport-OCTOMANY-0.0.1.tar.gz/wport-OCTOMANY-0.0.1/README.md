# wport

Quickly fetches the most common ports and service names information for pentesting. It uses the description and links to https://book.hacktricks.xyz/.

You can either specify a port number or a service name.

	wport 80
	wport HTTP
