# wport

Quickly fetches the most common ports and service names information for pentesting. It uses the description and links to https://book.hacktricks.xyz/.

usage : wport PORTorSERVICE